#pragma once
#include "CustomerFlowController.h"
#include "CustomersManager.h"
#include "AdminFlowController.h"

class UserFlowController {
private:
	CustomerFlowController customerFlowController;
	CustomersManager* customersManager = CustomersManager::GetInstance();
	AdminFlowController adminFlowController;
	void Login();
	void SignUp();
public:
	void ShowMainMenu();
	UserFlowController() {

	}
};